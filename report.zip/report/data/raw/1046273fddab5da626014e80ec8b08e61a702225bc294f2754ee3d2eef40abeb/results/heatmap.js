const heatmap_plot = {
    "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
    "data": {
        "values": []
    },
    "hconcat": [
        
        {
            
            "layer": [
            
            {
                "mark": {
                    "type": "rect",
                    "align":"left",
                    "width": 324
                },
                "encoding": {
                    "x": {
                        "field": "dummy",
                        "axis": {
                            "labelExpr": "'callset'",
                            "labelAngle": -90,
                            
                            "title": null,
                            "ticks": false,
                            "orient": "top",
                            "domain": false
                        }
                    },
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    },
                    "color": {
                        "field": "callset",
                        "type": "nominal",
                        "title": "callset",
                        "scale": {
                            "domain": ["BO-agilent-200M","CO-agilent-200M","DUE-varlociraptor","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","GHGA-sarek-dragmap-freebayes-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","TB-IMGAG-megSAP-freebayes-highsensitivity-agilent-200M","TB-sarek27-freebayes-agilent-200M","TB-sarek27-haplotypecaller-agilent-200M","TB-sarek27-strelka-agilent-200M","TB-sarek311-freebayes-agilent-200M","TB-sarek311-haplotypecaller-agilent-200M","TB-sarek311-strelka-agilent-200M","bonn-core-unit-agilent-200M"],
                            "type": "ordinal",
                            "scheme": "category20",
                            
                            
                        },
                        "legend": null
                    }
                }
            }
            ,
            {
                "mark": {
                    "type": "text",
                    "align":"left",
                    "xOffset": -6
                },
                "encoding": {
                    "text": {"field": "callset"},
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    }
                }
            }
        
        ]},
        
        {
            
            "layer": [
            
            {
                "mark": {
                    "type": "rect",
                    "align":"left",
                    "width": 36
                },
                "encoding": {
                    "x": {
                        "field": "dummy",
                        "axis": {
                            "labelExpr": "'coverage'",
                            "labelAngle": -90,
                            
                            "title": null,
                            "ticks": false,
                            "orient": "top",
                            "domain": false
                        }
                    },
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    },
                    "color": {
                        "field": "coverage",
                        "type": "nominal",
                        "title": "coverage",
                        "scale": {
                            "domain": ["low","medium","high"],
                            "type": "ordinal",
                            
                            "range": ["#c6dbef","#9ecae1","#6baed6"],
                            
                        },
                        "legend": null
                    }
                }
            }
            ,
            {
                "mark": {
                    "type": "text",
                    "align":"left",
                    "xOffset": -6
                },
                "encoding": {
                    "text": {"field": "coverage"},
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    }
                }
            }
        
        ]},
        
        {
            
            "layer": [
            
            {
                "mark": {
                    "type": "rect",
                    "align":"left",
                    "width": 108
                },
                "encoding": {
                    "x": {
                        "field": "dummy",
                        "axis": {
                            "labelExpr": "'precision'",
                            "labelAngle": -90,
                            
                            "title": null,
                            "ticks": false,
                            "orient": "top",
                            "domain": false
                        }
                    },
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    },
                    "color": {
                        "field": "precision",
                        "type": "quantitative",
                        "title": "precision",
                        "scale": {
                            "domain": [0.5695580840110779,1.0],
                            "type": "linear",
                            "scheme": "blues",
                            
                            
                        },
                        "legend": null
                    }
                }
            }
            ,
            {
                "mark": {
                    "type": "text",
                    "align":"left",
                    "xOffset": -6
                },
                "encoding": {
                    "text": {"field": "precision"},
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    }
                }
            }
        
        ]},
        
        {
            
            "layer": [
            
            {
                "mark": {
                    "type": "text",
                    "align":"left"
                },
                "encoding": {
                    "x": {
                        "field": "dummy",
                        "axis": {
                            "labelExpr": "'tp_query'",
                            "labelAngle": -90,
                            "labelOffset": 7,
                            "title": null,
                            "ticks": false,
                            "orient": "top",
                            "domain": false
                        }
                    },
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    },
                    "text": {
                        "field": "tp_query",
                        "type": "quantitative",
                        "title": "tp_query",
                        
                    }
                }
            }
            
        ]},
        
        {
            
            "layer": [
            
            {
                "mark": {
                    "type": "text",
                    "align":"left"
                },
                "encoding": {
                    "x": {
                        "field": "dummy",
                        "axis": {
                            "labelExpr": "'fp'",
                            "labelAngle": -90,
                            "labelOffset": 7,
                            "title": null,
                            "ticks": false,
                            "orient": "top",
                            "domain": false
                        }
                    },
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    },
                    "text": {
                        "field": "fp",
                        "type": "quantitative",
                        "title": "fp",
                        
                    }
                }
            }
            
        ]},
        
        {
            
            "layer": [
            
            {
                "mark": {
                    "type": "rect",
                    "align":"left",
                    "width": 108
                },
                "encoding": {
                    "x": {
                        "field": "dummy",
                        "axis": {
                            "labelExpr": "'recall'",
                            "labelAngle": -90,
                            
                            "title": null,
                            "ticks": false,
                            "orient": "top",
                            "domain": false
                        }
                    },
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    },
                    "color": {
                        "field": "recall",
                        "type": "quantitative",
                        "title": "recall",
                        "scale": {
                            "domain": [0.0658227875828743,0.9977749586105347],
                            "type": "linear",
                            "scheme": "blues",
                            
                            
                        },
                        "legend": null
                    }
                }
            }
            ,
            {
                "mark": {
                    "type": "text",
                    "align":"left",
                    "xOffset": -6
                },
                "encoding": {
                    "text": {"field": "recall"},
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    }
                }
            }
        
        ]},
        
        {
            
            "layer": [
            
            {
                "mark": {
                    "type": "text",
                    "align":"left"
                },
                "encoding": {
                    "x": {
                        "field": "dummy",
                        "axis": {
                            "labelExpr": "'tp_truth'",
                            "labelAngle": -90,
                            "labelOffset": 7,
                            "title": null,
                            "ticks": false,
                            "orient": "top",
                            "domain": false
                        }
                    },
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    },
                    "text": {
                        "field": "tp_truth",
                        "type": "quantitative",
                        "title": "tp_truth",
                        
                    }
                }
            }
            
        ]},
        
        {
            
            "layer": [
            
            {
                "mark": {
                    "type": "text",
                    "align":"left"
                },
                "encoding": {
                    "x": {
                        "field": "dummy",
                        "axis": {
                            "labelExpr": "'fn'",
                            "labelAngle": -90,
                            "labelOffset": 7,
                            "title": null,
                            "ticks": false,
                            "orient": "top",
                            "domain": false
                        }
                    },
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    },
                    "text": {
                        "field": "fn",
                        "type": "quantitative",
                        "title": "fn",
                        
                    }
                }
            }
            
        ]},
        
        {
            
            "layer": [
            
            {
                "mark": {
                    "type": "rect",
                    "align":"left",
                    "width": 108
                },
                "encoding": {
                    "x": {
                        "field": "dummy",
                        "axis": {
                            "labelExpr": "'genotype_mismatch_rate'",
                            "labelAngle": -90,
                            
                            "title": null,
                            "ticks": false,
                            "orient": "top",
                            "domain": false
                        }
                    },
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    },
                    "color": {
                        "field": "genotype_mismatch_rate",
                        "type": "quantitative",
                        "title": "genotype_mismatch_rate",
                        "scale": {
                            "domain": [0.0,0.04830917716026306],
                            "type": "linear",
                            "scheme": "blues",
                            
                            
                        },
                        "legend": null
                    }
                }
            }
            ,
            {
                "mark": {
                    "type": "text",
                    "align":"left",
                    "xOffset": -6
                },
                "encoding": {
                    "text": {"field": "genotype_mismatch_rate"},
                    "y": {
                        "field": "index",
                        "type": "ordinal",
                        "axis": null,
                    }
                }
            }
        
        ]}
        
    ],
    "config": {
        "style": {"cell": {"stroke": "transparent"}, "guide-label": {"fontWeight": "bold"}},
        "concat": {"spacing": 0},
        "text": {"limit": 135}
    }
}