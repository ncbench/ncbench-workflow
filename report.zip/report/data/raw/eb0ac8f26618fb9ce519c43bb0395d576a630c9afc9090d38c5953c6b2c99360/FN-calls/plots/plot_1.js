let show_plot_1 = true;
let plot_1 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"bin_end":5197504.0,"bin_start":null,"value":0},{"bin_end":16765178.0,"bin_start":5197504.0,"value":6},{"bin_end":28332852.0,"bin_start":16765178.0,"value":4},{"bin_end":39900528.0,"bin_start":28332852.0,"value":3},{"bin_end":51468200.0,"bin_start":39900528.0,"value":5},{"bin_end":63035880.0,"bin_start":51468200.0,"value":1},{"bin_end":74603552.0,"bin_start":63035880.0,"value":0},{"bin_end":86171224.0,"bin_start":74603552.0,"value":0},{"bin_end":97738896.0,"bin_start":86171224.0,"value":1},{"bin_end":109306576.0,"bin_start":97738896.0,"value":1},{"bin_end":120874256.0,"bin_start":109306576.0,"value":0},{"bin_end":132441920.0,"bin_start":120874256.0,"value":0},{"bin_end":144009600.0,"bin_start":132441920.0,"value":1},{"bin_end":155577264.0,"bin_start":144009600.0,"value":0},{"bin_end":167144944.0,"bin_start":155577264.0,"value":0},{"bin_end":178712608.0,"bin_start":167144944.0,"value":0},{"bin_end":190280288.0,"bin_start":178712608.0,"value":1},{"bin_end":201847968.0,"bin_start":190280288.0,"value":0},{"bin_end":213415648.0,"bin_start":201847968.0,"value":1},{"bin_end":224983312.0,"bin_start":213415648.0,"value":0},{"bin_end":236551008.0,"bin_start":224983312.0,"value":0},{"bin_end":null,"bin_start":236550992.0,"value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "bin_start",
                    "bin": "binned",
                    "title": "position"
                },
                "x2": {"field": "bin_end"},
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        },
        {
            "data": {
                "values":[]
            },
            "mark": "rule",
            "encoding": {
                "x": {"field": "bin_start", "bin": "binned"},
                "color": {"value": "red"}
            }
        }
    ]
};
