let show_plot_1 = true;
let plot_1 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"bin_end":3134446.0,"bin_start":null,"value":0},{"bin_end":14805273.0,"bin_start":3134446.0,"value":6},{"bin_end":26476100.0,"bin_start":14805273.0,"value":6},{"bin_end":38146928.0,"bin_start":26476100.0,"value":4},{"bin_end":49817752.0,"bin_start":38146928.0,"value":6},{"bin_end":61488584.0,"bin_start":49817752.0,"value":1},{"bin_end":73159408.0,"bin_start":61488584.0,"value":0},{"bin_end":84830240.0,"bin_start":73159408.0,"value":0},{"bin_end":96501064.0,"bin_start":84830240.0,"value":1},{"bin_end":108171896.0,"bin_start":96501064.0,"value":2},{"bin_end":119842720.0,"bin_start":108171896.0,"value":0},{"bin_end":131513544.0,"bin_start":119842720.0,"value":0},{"bin_end":143184368.0,"bin_start":131513544.0,"value":0},{"bin_end":154855200.0,"bin_start":143184368.0,"value":1},{"bin_end":166526032.0,"bin_start":154855200.0,"value":0},{"bin_end":178196864.0,"bin_start":166526032.0,"value":1},{"bin_end":189867680.0,"bin_start":178196864.0,"value":1},{"bin_end":201538512.0,"bin_start":189867680.0,"value":0},{"bin_end":213209344.0,"bin_start":201538512.0,"value":1},{"bin_end":224880160.0,"bin_start":213209344.0,"value":0},{"bin_end":236550992.0,"bin_start":224880160.0,"value":0},{"bin_end":null,"bin_start":236550992.0,"value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "bin_start",
                    "bin": "binned",
                    "title": "position"
                },
                "x2": {"field": "bin_end"},
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        },
        {
            "data": {
                "values":[]
            },
            "mark": "rule",
            "encoding": {
                "x": {"field": "bin_start", "bin": "binned"},
                "color": {"value": "red"}
            }
        }
    ]
};
