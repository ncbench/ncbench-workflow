let show_plot_2 = true;
let plot_2 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"C","value":3},{"key":"CT","value":1},{"key":"G","value":9},{"key":"T","value":6},{"key":"A","value":7}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "ref_allele"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
