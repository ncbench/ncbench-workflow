let show_plot_4 = true;
let plot_4 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"0/1","value":21},{"key":"1/1","value":7}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "true_genotype"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
