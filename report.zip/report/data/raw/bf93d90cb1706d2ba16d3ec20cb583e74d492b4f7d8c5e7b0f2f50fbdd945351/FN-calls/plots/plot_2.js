let show_plot_2 = true;
let plot_2 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"G","value":23},{"key":"C","value":22},{"key":"T","value":17},{"key":"A","value":12},{"key":"CT","value":1},{"key":"ATTTT","value":1},{"key":"TTGTG","value":1},{"key":"GT","value":1},{"key":"GAA","value":1},{"key":"GTT","value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "ref_allele"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
