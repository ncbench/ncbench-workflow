let show_plot_3 = true;
let plot_3 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"T","value":12},{"key":"CTT","value":7},{"key":"C","value":6},{"key":"GA","value":6},{"key":"TAA","value":5},{"key":"CTTT","value":4},{"key":"AT","value":4},{"key":"GAA","value":3},{"key":"ATT","value":3},{"key":"GAAA","value":2}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "alt_allele"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
