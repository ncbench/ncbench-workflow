let show_plot_0 = true;
let plot_0 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"bin_end":1.0,"bin_start":null,"value":0},{"bin_end":2.049999952316284,"bin_start":1.0,"value":16},{"bin_end":3.0999999046325684,"bin_start":2.049999952316284,"value":1},{"bin_end":4.150000095367432,"bin_start":3.0999999046325684,"value":3},{"bin_end":5.199999809265137,"bin_start":4.150000095367432,"value":3},{"bin_end":6.25,"bin_start":5.199999809265137,"value":15},{"bin_end":7.300000190734863,"bin_start":6.25,"value":3},{"bin_end":8.350000381469727,"bin_start":7.300000190734863,"value":1},{"bin_end":9.399999618530273,"bin_start":8.350000381469727,"value":3},{"bin_end":10.449999809265137,"bin_start":9.399999618530273,"value":6},{"bin_end":11.5,"bin_start":10.449999809265137,"value":3},{"bin_end":12.550000190734863,"bin_start":11.5,"value":5},{"bin_end":13.600000381469727,"bin_start":12.550000190734863,"value":4},{"bin_end":14.649999618530273,"bin_start":13.600000381469727,"value":4},{"bin_end":15.699999809265137,"bin_start":14.649999618530273,"value":1},{"bin_end":16.75,"bin_start":15.699999809265137,"value":0},{"bin_end":17.799999237060547,"bin_start":16.75,"value":6},{"bin_end":18.850000381469727,"bin_start":17.799999237060547,"value":5},{"bin_end":19.899999618530273,"bin_start":18.850000381469727,"value":5},{"bin_end":20.950000762939453,"bin_start":19.899999618530273,"value":2},{"bin_end":22.0,"bin_start":20.950000762939453,"value":0},{"bin_end":null,"bin_start":22.0,"value":2}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "bin_start",
                    "bin": "binned",
                    "title": "chromosome"
                },
                "x2": {"field": "bin_end"},
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        },
        {
            "data": {
                "values":[]
            },
            "mark": "rule",
            "encoding": {
                "x": {"field": "bin_start", "bin": "binned"},
                "color": {"value": "red"}
            }
        }
    ]
};
