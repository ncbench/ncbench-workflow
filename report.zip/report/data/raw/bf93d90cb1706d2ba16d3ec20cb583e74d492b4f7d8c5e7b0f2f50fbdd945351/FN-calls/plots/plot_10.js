let show_plot_10 = false;
let plot_10 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": null},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "DUE-varlociraptor"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
