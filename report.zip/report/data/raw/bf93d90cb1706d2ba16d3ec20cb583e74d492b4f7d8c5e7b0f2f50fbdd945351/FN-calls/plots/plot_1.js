let show_plot_1 = true;
let plot_1 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"bin_end":239539.0,"bin_start":null,"value":0},{"bin_end":11706987.0,"bin_start":239539.0,"value":10},{"bin_end":23174436.0,"bin_start":11706987.0,"value":7},{"bin_end":34641884.0,"bin_start":23174436.0,"value":16},{"bin_end":46109332.0,"bin_start":34641884.0,"value":6},{"bin_end":57576780.0,"bin_start":46109332.0,"value":6},{"bin_end":69044224.0,"bin_start":57576780.0,"value":2},{"bin_end":80511672.0,"bin_start":69044224.0,"value":5},{"bin_end":91979120.0,"bin_start":80511672.0,"value":0},{"bin_end":103446568.0,"bin_start":91979120.0,"value":5},{"bin_end":114914016.0,"bin_start":103446568.0,"value":2},{"bin_end":126381464.0,"bin_start":114914016.0,"value":3},{"bin_end":137848912.0,"bin_start":126381464.0,"value":5},{"bin_end":149316368.0,"bin_start":137848912.0,"value":1},{"bin_end":160783808.0,"bin_start":149316368.0,"value":5},{"bin_end":172251264.0,"bin_start":160783808.0,"value":1},{"bin_end":183718704.0,"bin_start":172251264.0,"value":1},{"bin_end":195186144.0,"bin_start":183718704.0,"value":1},{"bin_end":206653600.0,"bin_start":195186144.0,"value":1},{"bin_end":218121056.0,"bin_start":206653600.0,"value":1},{"bin_end":229588496.0,"bin_start":218121056.0,"value":0},{"bin_end":null,"bin_start":229588496.0,"value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "bin_start",
                    "bin": "binned",
                    "title": "position"
                },
                "x2": {"field": "bin_end"},
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        },
        {
            "data": {
                "values":[]
            },
            "mark": "rule",
            "encoding": {
                "x": {"field": "bin_start", "bin": "binned"},
                "color": {"value": "red"}
            }
        }
    ]
};
