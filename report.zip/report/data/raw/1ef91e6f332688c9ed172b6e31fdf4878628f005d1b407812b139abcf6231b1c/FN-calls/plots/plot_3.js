let show_plot_3 = true;
let plot_3 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"GA","value":2},{"key":"G","value":2},{"key":"AG","value":2},{"key":"C","value":2},{"key":"CTT","value":1},{"key":"ATGTGTGTGTGTGTGTGTGTGTGTG","value":1},{"key":"CT","value":1},{"key":"TA","value":1},{"key":"A","value":1},{"key":"GAAA","value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "alt_allele"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
