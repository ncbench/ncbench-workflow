let show_plot_1 = true;
let plot_1 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"bin_end":2696508.0,"bin_start":null,"value":0},{"bin_end":11820099.0,"bin_start":2696508.0,"value":1},{"bin_end":20943690.0,"bin_start":11820099.0,"value":2},{"bin_end":30067282.0,"bin_start":20943690.0,"value":2},{"bin_end":39190872.0,"bin_start":30067282.0,"value":3},{"bin_end":48314464.0,"bin_start":39190872.0,"value":1},{"bin_end":57438056.0,"bin_start":48314464.0,"value":1},{"bin_end":66561648.0,"bin_start":57438056.0,"value":0},{"bin_end":75685232.0,"bin_start":66561648.0,"value":0},{"bin_end":84808832.0,"bin_start":75685232.0,"value":1},{"bin_end":93932416.0,"bin_start":84808832.0,"value":1},{"bin_end":103056016.0,"bin_start":93932416.0,"value":1},{"bin_end":112179600.0,"bin_start":103056016.0,"value":0},{"bin_end":121303184.0,"bin_start":112179600.0,"value":1},{"bin_end":130426784.0,"bin_start":121303184.0,"value":1},{"bin_end":139550368.0,"bin_start":130426784.0,"value":1},{"bin_end":148673968.0,"bin_start":139550368.0,"value":0},{"bin_end":157797568.0,"bin_start":148673968.0,"value":0},{"bin_end":166921152.0,"bin_start":157797568.0,"value":0},{"bin_end":176044752.0,"bin_start":166921152.0,"value":0},{"bin_end":185168336.0,"bin_start":176044752.0,"value":0},{"bin_end":null,"bin_start":185168336.0,"value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "bin_start",
                    "bin": "binned",
                    "title": "position"
                },
                "x2": {"field": "bin_end"},
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        },
        {
            "data": {
                "values":[]
            },
            "mark": "rule",
            "encoding": {
                "x": {"field": "bin_start", "bin": "binned"},
                "color": {"value": "red"}
            }
        }
    ]
};
