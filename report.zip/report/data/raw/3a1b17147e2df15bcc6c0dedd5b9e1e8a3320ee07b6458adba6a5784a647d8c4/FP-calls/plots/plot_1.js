let show_plot_1 = true;
let plot_1 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"bin_end":2335447.0,"bin_start":null,"value":0},{"bin_end":13698100.0,"bin_start":2335447.0,"value":6},{"bin_end":25060752.0,"bin_start":13698100.0,"value":9},{"bin_end":36423408.0,"bin_start":25060752.0,"value":8},{"bin_end":47786060.0,"bin_start":36423408.0,"value":3},{"bin_end":59148708.0,"bin_start":47786060.0,"value":8},{"bin_end":70511368.0,"bin_start":59148708.0,"value":1},{"bin_end":81874024.0,"bin_start":70511368.0,"value":3},{"bin_end":93236672.0,"bin_start":81874024.0,"value":2},{"bin_end":104599320.0,"bin_start":93236672.0,"value":5},{"bin_end":115961968.0,"bin_start":104599320.0,"value":1},{"bin_end":127324632.0,"bin_start":115961968.0,"value":3},{"bin_end":138687280.0,"bin_start":127324632.0,"value":3},{"bin_end":150049920.0,"bin_start":138687280.0,"value":1},{"bin_end":161412592.0,"bin_start":150049920.0,"value":2},{"bin_end":172775232.0,"bin_start":161412592.0,"value":0},{"bin_end":184137888.0,"bin_start":172775232.0,"value":0},{"bin_end":195500528.0,"bin_start":184137888.0,"value":0},{"bin_end":206863184.0,"bin_start":195500528.0,"value":1},{"bin_end":218225840.0,"bin_start":206863184.0,"value":0},{"bin_end":229588480.0,"bin_start":218225840.0,"value":1},{"bin_end":null,"bin_start":229588496.0,"value":2}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "bin_start",
                    "bin": "binned",
                    "title": "position"
                },
                "x2": {"field": "bin_end"},
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        },
        {
            "data": {
                "values":[]
            },
            "mark": "rule",
            "encoding": {
                "x": {"field": "bin_start", "bin": "binned"},
                "color": {"value": "red"}
            }
        }
    ]
};
