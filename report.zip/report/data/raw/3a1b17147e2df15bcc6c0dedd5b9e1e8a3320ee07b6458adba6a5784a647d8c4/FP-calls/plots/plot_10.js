let show_plot_10 = true;
let plot_10 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"0/1","value":9},{"key":"1/1","value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "TB-sarek-strelka-agilent-200M"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
