let show_plot_2 = true;
let plot_2 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"A","value":8},{"key":"GTT","value":1},{"key":"G","value":22},{"key":"TAA","value":1},{"key":"ATTTT","value":1},{"key":"T","value":12},{"key":"C","value":14}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "ref_allele"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
