let show_plot_3 = true;
let plot_3 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"T","value":8},{"key":"A","value":8},{"key":"TA","value":5},{"key":"C","value":5},{"key":"CT","value":5},{"key":"G","value":4},{"key":"CTT","value":4},{"key":"TAA","value":3},{"key":"AT","value":3},{"key":"GTT","value":3}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "alt_allele"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
