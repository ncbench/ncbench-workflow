let show_plot_3 = true;
let plot_3 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"A","value":11},{"key":"T","value":9},{"key":"C","value":6},{"key":"CT","value":6},{"key":"TA","value":5},{"key":"CTT","value":4},{"key":"AT","value":4},{"key":"G","value":4},{"key":"GTT","value":3},{"key":"TAA","value":3}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "alt_allele"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
