let show_plot_28 = true;
let plot_28 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"0/1","value":18},{"key":"1/1","value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "TB-sarek-freebayes-agilent-200M"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
