let show_plot_3 = true;
let plot_3 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"T","value":2},{"key":"A","value":4},{"key":"C","value":2},{"key":"G","value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "alt_allele"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
