let show_plot_0 = true;
let plot_0 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"bin_end":1.0,"bin_start":null,"value":0},{"bin_end":1.899999976158142,"bin_start":1.0,"value":1},{"bin_end":2.799999952316284,"bin_start":1.899999976158142,"value":0},{"bin_end":3.700000047683716,"bin_start":2.799999952316284,"value":0},{"bin_end":4.599999904632568,"bin_start":3.700000047683716,"value":0},{"bin_end":5.5,"bin_start":4.599999904632568,"value":0},{"bin_end":6.400000095367432,"bin_start":5.5,"value":1},{"bin_end":7.300000190734863,"bin_start":6.400000095367432,"value":0},{"bin_end":8.199999809265137,"bin_start":7.300000190734863,"value":0},{"bin_end":9.100000381469727,"bin_start":8.199999809265137,"value":1},{"bin_end":10.0,"bin_start":9.100000381469727,"value":0},{"bin_end":10.899999618530273,"bin_start":10.0,"value":0},{"bin_end":11.800000190734863,"bin_start":10.899999618530273,"value":0},{"bin_end":12.699999809265137,"bin_start":11.800000190734863,"value":2},{"bin_end":13.600000381469727,"bin_start":12.699999809265137,"value":0},{"bin_end":14.5,"bin_start":13.600000381469727,"value":1},{"bin_end":15.399999618530273,"bin_start":14.5,"value":0},{"bin_end":16.299999237060547,"bin_start":15.399999618530273,"value":0},{"bin_end":17.200000762939453,"bin_start":16.299999237060547,"value":2},{"bin_end":18.100000381469727,"bin_start":17.200000762939453,"value":0},{"bin_end":19.0,"bin_start":18.100000381469727,"value":0},{"bin_end":null,"bin_start":19.0,"value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "bin_start",
                    "bin": "binned",
                    "title": "chromosome"
                },
                "x2": {"field": "bin_end"},
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        },
        {
            "data": {
                "values":[]
            },
            "mark": "rule",
            "encoding": {
                "x": {"field": "bin_start", "bin": "binned"},
                "color": {"value": "red"}
            }
        }
    ]
};
