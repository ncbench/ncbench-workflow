let show_plot_1 = true;
let plot_1 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"bin_end":3134435.0,"bin_start":null,"value":0},{"bin_end":12236130.0,"bin_start":3134435.0,"value":2},{"bin_end":21337824.0,"bin_start":12236130.0,"value":2},{"bin_end":30439520.0,"bin_start":21337824.0,"value":0},{"bin_end":39541216.0,"bin_start":30439520.0,"value":0},{"bin_end":48642912.0,"bin_start":39541216.0,"value":1},{"bin_end":57744604.0,"bin_start":48642912.0,"value":2},{"bin_end":66846300.0,"bin_start":57744604.0,"value":0},{"bin_end":75947992.0,"bin_start":66846300.0,"value":0},{"bin_end":85049688.0,"bin_start":75947992.0,"value":0},{"bin_end":94151384.0,"bin_start":85049688.0,"value":1},{"bin_end":103253080.0,"bin_start":94151384.0,"value":0},{"bin_end":112354768.0,"bin_start":103253080.0,"value":0},{"bin_end":121456464.0,"bin_start":112354768.0,"value":0},{"bin_end":130558160.0,"bin_start":121456464.0,"value":2},{"bin_end":139659856.0,"bin_start":130558160.0,"value":0},{"bin_end":148761552.0,"bin_start":139659856.0,"value":0},{"bin_end":157863248.0,"bin_start":148761552.0,"value":0},{"bin_end":166964944.0,"bin_start":157863248.0,"value":0},{"bin_end":176066640.0,"bin_start":166964944.0,"value":0},{"bin_end":185168336.0,"bin_start":176066640.0,"value":0},{"bin_end":null,"bin_start":185168336.0,"value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "bin_start",
                    "bin": "binned",
                    "title": "position"
                },
                "x2": {"field": "bin_end"},
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        },
        {
            "data": {
                "values":[]
            },
            "mark": "rule",
            "encoding": {
                "x": {"field": "bin_start", "bin": "binned"},
                "color": {"value": "red"}
            }
        }
    ]
};
