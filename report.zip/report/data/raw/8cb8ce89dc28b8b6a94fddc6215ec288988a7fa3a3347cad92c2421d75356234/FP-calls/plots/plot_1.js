let show_plot_1 = true;
let plot_1 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"bin_end":18383616.0,"bin_start":null,"value":0},{"bin_end":26722852.0,"bin_start":18383616.0,"value":2},{"bin_end":35062088.0,"bin_start":26722852.0,"value":0},{"bin_end":43401324.0,"bin_start":35062088.0,"value":0},{"bin_end":51740560.0,"bin_start":43401324.0,"value":3},{"bin_end":60079796.0,"bin_start":51740560.0,"value":0},{"bin_end":68419032.0,"bin_start":60079796.0,"value":0},{"bin_end":76758264.0,"bin_start":68419032.0,"value":0},{"bin_end":85097504.0,"bin_start":76758264.0,"value":0},{"bin_end":93436744.0,"bin_start":85097504.0,"value":1},{"bin_end":101775976.0,"bin_start":93436744.0,"value":0},{"bin_end":110115216.0,"bin_start":101775976.0,"value":0},{"bin_end":118454448.0,"bin_start":110115216.0,"value":0},{"bin_end":126793688.0,"bin_start":118454448.0,"value":1},{"bin_end":135132912.0,"bin_start":126793688.0,"value":1},{"bin_end":143472160.0,"bin_start":135132912.0,"value":0},{"bin_end":151811392.0,"bin_start":143472160.0,"value":0},{"bin_end":160150624.0,"bin_start":151811392.0,"value":0},{"bin_end":168489872.0,"bin_start":160150624.0,"value":0},{"bin_end":176829088.0,"bin_start":168489872.0,"value":0},{"bin_end":185168336.0,"bin_start":176829088.0,"value":0},{"bin_end":null,"bin_start":185168336.0,"value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "bin_start",
                    "bin": "binned",
                    "title": "position"
                },
                "x2": {"field": "bin_end"},
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        },
        {
            "data": {
                "values":[]
            },
            "mark": "rule",
            "encoding": {
                "x": {"field": "bin_start", "bin": "binned"},
                "color": {"value": "red"}
            }
        }
    ]
};
