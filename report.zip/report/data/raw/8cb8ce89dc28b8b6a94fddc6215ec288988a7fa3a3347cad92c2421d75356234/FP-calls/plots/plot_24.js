let show_plot_24 = false;
let plot_24 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": null},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "GHGA-sarek-dragmap-haplotypecaller-agilent-200M"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
