let show_plot_15 = false;
let plot_15 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": null},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "TB-sarek-freebayes-agilent-200M"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
