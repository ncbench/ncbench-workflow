$(document).ready(function() {
    $('.table-container').show();
    $('.loading').hide();
    $('#pagination').show();
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    });
    $(function () {
        $('[data-toggle="popover"]').popover()
    });
    $('.modal').on('shown.bs.modal', function () {
        window.dispatchEvent(new Event('resize'));
    });
    var decompressed = JSON.parse(LZString.decompressFromUTF16(data));

    if (linkouts != null) {
        var decompressed_linkouts = JSON.parse(LZString.decompressFromUTF16(linkouts));
    }

    var format = [];

    let bs_table_cols = [{
    field: 'chromosome',
    title: 'chromosome\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_0\" onclick=\"if (show_plot_0) {vegaEmbed(\'#plot_0\', plot_0)} else {document.getElementById(\'plot_0\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'position',
    title: 'position\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_1\" onclick=\"if (show_plot_1) {vegaEmbed(\'#plot_1\', plot_1)} else {document.getElementById(\'plot_1\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'ref_allele',
    title: 'ref_allele\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_2\" onclick=\"if (show_plot_2) {vegaEmbed(\'#plot_2\', plot_2)} else {document.getElementById(\'plot_2\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'alt_allele',
    title: 'alt_allele\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_3\" onclick=\"if (show_plot_3) {vegaEmbed(\'#plot_3\', plot_3)} else {document.getElementById(\'plot_3\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'true_genotype',
    title: 'true_genotype\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_4\" onclick=\"if (show_plot_4) {vegaEmbed(\'#plot_4\', plot_4)} else {document.getElementById(\'plot_4\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'TB-sarek-freebayes-agilent-75M',
    title: 'TB-sarek-freebayes-agilent-75M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_5\" onclick=\"if (show_plot_5) {vegaEmbed(\'#plot_5\', plot_5)} else {document.getElementById(\'plot_5\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'GHGA-sarek-dragmap-freebayes-agilent-200M',
    title: 'GHGA-sarek-dragmap-freebayes-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_6\" onclick=\"if (show_plot_6) {vegaEmbed(\'#plot_6\', plot_6)} else {document.getElementById(\'plot_6\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'CO-agilent-75M',
    title: 'CO-agilent-75M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_7\" onclick=\"if (show_plot_7) {vegaEmbed(\'#plot_7\', plot_7)} else {document.getElementById(\'plot_7\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'BO-agilent-200M',
    title: 'BO-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_8\" onclick=\"if (show_plot_8) {vegaEmbed(\'#plot_8\', plot_8)} else {document.getElementById(\'plot_8\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'DUE-varlociraptor',
    title: 'DUE-varlociraptor\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_9\" onclick=\"if (show_plot_9) {vegaEmbed(\'#plot_9\', plot_9)} else {document.getElementById(\'plot_9\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'TB-sarek-haplotypecaller-agilent-75M',
    title: 'TB-sarek-haplotypecaller-agilent-75M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_10\" onclick=\"if (show_plot_10) {vegaEmbed(\'#plot_10\', plot_10)} else {document.getElementById(\'plot_10\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'TB-sarek-haplotypecaller-agilent-200M',
    title: 'TB-sarek-haplotypecaller-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_11\" onclick=\"if (show_plot_11) {vegaEmbed(\'#plot_11\', plot_11)} else {document.getElementById(\'plot_11\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'TB-sarek-freebayes-agilent-200M',
    title: 'TB-sarek-freebayes-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_12\" onclick=\"if (show_plot_12) {vegaEmbed(\'#plot_12\', plot_12)} else {document.getElementById(\'plot_12\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'GHGA-sarek-bwa-deepvariant-agilent-200M',
    title: 'GHGA-sarek-bwa-deepvariant-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_13\" onclick=\"if (show_plot_13) {vegaEmbed(\'#plot_13\', plot_13)} else {document.getElementById(\'plot_13\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'GHGA-sarek-bwa-freebayes-agilent-200M',
    title: 'GHGA-sarek-bwa-freebayes-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_14\" onclick=\"if (show_plot_14) {vegaEmbed(\'#plot_14\', plot_14)} else {document.getElementById(\'plot_14\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'GHGA-sarek-bwa-haplotypecaller-agilent-200M',
    title: 'GHGA-sarek-bwa-haplotypecaller-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_15\" onclick=\"if (show_plot_15) {vegaEmbed(\'#plot_15\', plot_15)} else {document.getElementById(\'plot_15\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'GHGA-sarek-dragmap-deepvariant-agilent-200M',
    title: 'GHGA-sarek-dragmap-deepvariant-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_16\" onclick=\"if (show_plot_16) {vegaEmbed(\'#plot_16\', plot_16)} else {document.getElementById(\'plot_16\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'CO-agilent-200M',
    title: 'CO-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_17\" onclick=\"if (show_plot_17) {vegaEmbed(\'#plot_17\', plot_17)} else {document.getElementById(\'plot_17\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'GHGA-sarek-dragmap-haplotypecaller-agilent-200M',
    title: 'GHGA-sarek-dragmap-haplotypecaller-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_18\" onclick=\"if (show_plot_18) {vegaEmbed(\'#plot_18\', plot_18)} else {document.getElementById(\'plot_18\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'TB-sarek-strelka-agilent-75M',
    title: 'TB-sarek-strelka-agilent-75M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_19\" onclick=\"if (show_plot_19) {vegaEmbed(\'#plot_19\', plot_19)} else {document.getElementById(\'plot_19\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'TB-sarek-strelka-agilent-200M',
    title: 'TB-sarek-strelka-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_20\" onclick=\"if (show_plot_20) {vegaEmbed(\'#plot_20\', plot_20)} else {document.getElementById(\'plot_20\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'GHGA-sarek-dragmap-strelka-agilent-200M',
    title: 'GHGA-sarek-dragmap-strelka-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_21\" onclick=\"if (show_plot_21) {vegaEmbed(\'#plot_21\', plot_21)} else {document.getElementById(\'plot_21\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    },{
    field: 'GHGA-sarek-bwa-strelka-agilent-200M',
    title: 'GHGA-sarek-bwa-strelka-agilent-200M\r\n                        <a class=\"sym\" data-toggle=\"modal\" data-target=\"#modal_22\" onclick=\"if (show_plot_22) {vegaEmbed(\'#plot_22\', plot_22)} else {document.getElementById(\'plot_22\').innerHTML = \'<p>No reasonable plot possible.</p>\'}\">\r\n                            <svg width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\" class=\"bi bi-bar-chart-fill\" fill=\"currentColor\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\">\r\n                                <rect width=\"4\" height=\"5\" x=\"1\" y=\"10\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"9\" x=\"6\" y=\"6\" rx=\"1\"\/>\r\n                                <rect width=\"4\" height=\"14\" x=\"11\" y=\"1\" rx=\"1\"\/>\r\n                            <\/svg>\r\n                        <\/a>\r\n                        ',filterControl: "input"
    }];

    if (linkouts != null) {
        bs_table_cols.push({field: 'linkouts', title: '', formatter: function(value){ return value }});
    }

    $('#table').bootstrapTable({
        columns: bs_table_cols,
        pagination: true,
        data: [],
        
    })

    let additional_headers = [];
    let columns = ["chromosome","position","ref_allele","alt_allele","true_genotype","TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"];
    let displayed_columns = ["chromosome","position","ref_allele","alt_allele","true_genotype","TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"];
    let num = [true,true,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false];
    let dp_num = [true,true,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false];
    let ticks = [];
    let cp = [];
    let links = [];

    var header_height = (80+6*Math.max(...(displayed_columns.map(el => el.length)))*Math.SQRT2)/2  + 45;
    $('th').css("height", header_height);

    var table_rows = [];
    var j = 0;
    for (const r of decompressed) {
        var i = 0;
        row = {};
        for (const element of r) {
            row[columns[i]] = element;
            i++;
        }
        if (linkouts != null) {
            row["linkouts"] = decompressed_linkouts[j];
        }
        j++;
        table_rows.push(row);
    }
    $('#table').bootstrapTable('append', additional_headers)
    $('#table').bootstrapTable('append', table_rows)

    $('#table').on('expand-row.bs.table', (event, index, row, detailView) => {
        let cp = [];
        let ticks = [];
        let heatmaps = ["BO-agilent-200M","CO-agilent-200M","CO-agilent-75M","DUE-varlociraptor","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","GHGA-sarek-dragmap-freebayes-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","TB-sarek-freebayes-agilent-200M","TB-sarek-freebayes-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-strelka-agilent-200M","TB-sarek-strelka-agilent-75M","true_genotype"];
        let columns = ["chromosome","position","ref_allele","alt_allele","true_genotype","TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"];
        
        
        colorizeDetailCard0(row[heatmaps[0]], `#heatmap-${index}-0`);
        
        colorizeDetailCard1(row[heatmaps[1]], `#heatmap-${index}-1`);
        
        colorizeDetailCard2(row[heatmaps[2]], `#heatmap-${index}-2`);
        
        colorizeDetailCard3(row[heatmaps[3]], `#heatmap-${index}-3`);
        
        colorizeDetailCard4(row[heatmaps[4]], `#heatmap-${index}-4`);
        
        colorizeDetailCard5(row[heatmaps[5]], `#heatmap-${index}-5`);
        
        colorizeDetailCard6(row[heatmaps[6]], `#heatmap-${index}-6`);
        
        colorizeDetailCard7(row[heatmaps[7]], `#heatmap-${index}-7`);
        
        colorizeDetailCard8(row[heatmaps[8]], `#heatmap-${index}-8`);
        
        colorizeDetailCard9(row[heatmaps[9]], `#heatmap-${index}-9`);
        
        colorizeDetailCard10(row[heatmaps[10]], `#heatmap-${index}-10`);
        
        colorizeDetailCard11(row[heatmaps[11]], `#heatmap-${index}-11`);
        
        colorizeDetailCard12(row[heatmaps[12]], `#heatmap-${index}-12`);
        
        colorizeDetailCard13(row[heatmaps[13]], `#heatmap-${index}-13`);
        
        colorizeDetailCard14(row[heatmaps[14]], `#heatmap-${index}-14`);
        
        colorizeDetailCard15(row[heatmaps[15]], `#heatmap-${index}-15`);
        
        colorizeDetailCard16(row[heatmaps[16]], `#heatmap-${index}-16`);
        
        colorizeDetailCard17(row[heatmaps[17]], `#heatmap-${index}-17`);
        
        colorizeDetailCard18(row[heatmaps[18]], `#heatmap-${index}-18`);
        
        
    })

    $( ".btn-sm" ).click(function() {
        var col = $(this).data( "col" );
        var field = $(this).data("val").toString();
        if (field.startsWith("<div")) {
            var temp = $(field);
            field = temp[0].dataset.value;
        }
        var marker = { "bin_start": field};
        var index = columns.indexOf(col);
        switch (index) {
            case 0:
                if (plot_0["layer"].length > 1) {
                    $('#modal_0').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_0));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_0', marked_plot);
                }
                break;
            case 1:
                if (plot_1["layer"].length > 1) {
                    $('#modal_1').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_1));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_1', marked_plot);
                }
                break;
            case 2:
                if (plot_2["layer"].length > 1) {
                    $('#modal_2').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_2));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_2', marked_plot);
                }
                break;
            case 3:
                if (plot_3["layer"].length > 1) {
                    $('#modal_3').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_3));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_3', marked_plot);
                }
                break;
            case 4:
                if (plot_4["layer"].length > 1) {
                    $('#modal_4').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_4));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_4', marked_plot);
                }
                break;
            case 5:
                if (plot_5["layer"].length > 1) {
                    $('#modal_5').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_5));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_5', marked_plot);
                }
                break;
            case 6:
                if (plot_6["layer"].length > 1) {
                    $('#modal_6').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_6));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_6', marked_plot);
                }
                break;
            case 7:
                if (plot_7["layer"].length > 1) {
                    $('#modal_7').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_7));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_7', marked_plot);
                }
                break;
            case 8:
                if (plot_8["layer"].length > 1) {
                    $('#modal_8').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_8));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_8', marked_plot);
                }
                break;
            case 9:
                if (plot_9["layer"].length > 1) {
                    $('#modal_9').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_9));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_9', marked_plot);
                }
                break;
            case 10:
                if (plot_10["layer"].length > 1) {
                    $('#modal_10').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_10));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_10', marked_plot);
                }
                break;
            case 11:
                if (plot_11["layer"].length > 1) {
                    $('#modal_11').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_11));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_11', marked_plot);
                }
                break;
            case 12:
                if (plot_12["layer"].length > 1) {
                    $('#modal_12').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_12));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_12', marked_plot);
                }
                break;
            case 13:
                if (plot_13["layer"].length > 1) {
                    $('#modal_13').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_13));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_13', marked_plot);
                }
                break;
            case 14:
                if (plot_14["layer"].length > 1) {
                    $('#modal_14').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_14));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_14', marked_plot);
                }
                break;
            case 15:
                if (plot_15["layer"].length > 1) {
                    $('#modal_15').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_15));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_15', marked_plot);
                }
                break;
            case 16:
                if (plot_16["layer"].length > 1) {
                    $('#modal_16').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_16));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_16', marked_plot);
                }
                break;
            case 17:
                if (plot_17["layer"].length > 1) {
                    $('#modal_17').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_17));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_17', marked_plot);
                }
                break;
            case 18:
                if (plot_18["layer"].length > 1) {
                    $('#modal_18').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_18));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_18', marked_plot);
                }
                break;
            case 19:
                if (plot_19["layer"].length > 1) {
                    $('#modal_19').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_19));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_19', marked_plot);
                }
                break;
            case 20:
                if (plot_20["layer"].length > 1) {
                    $('#modal_20').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_20));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_20', marked_plot);
                }
                break;
            case 21:
                if (plot_21["layer"].length > 1) {
                    $('#modal_21').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_21));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_21', marked_plot);
                }
                break;
            case 22:
                if (plot_22["layer"].length > 1) {
                    $('#modal_22').modal();
                    var marked_plot = JSON.parse(JSON.stringify(plot_22));
                    marked_plot["layer"][1]["data"]["values"].push(marker);
                    vegaEmbed('#plot_22', marked_plot);
                }
                break;
            
        }
    });
    addNumClass(dp_num, additional_headers.length);

    render(additional_headers, displayed_columns, table_rows, columns);

    
    $('.btn-group + .bootstrap-select').before($('<div class="btn-group" style="padding-right: 4px;"><button class="btn btn-primary" type="button" id="clear-filter">clear filters</button></div>'))
    let filter_boundaries = {};
    let filters = {};
    let tick_brush_specs = {
        "width": 50,
        "height": 12,
        "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
        "data": {"values":[]},
        "mark": "tick",
        "encoding": {
            "tooltip": {"field": "value", "type": "quantitative"},
            "x": {
                "field": "value",
                "type": "quantitative",
                "scale": {"type": "linear", "zero": false},
                "axis": {
                    "title": null,
                    "orient": "top",
                    "labelFontWeight": "lighter"
                }
            },
            "color": {"condition": {"param": "selection", "value": "#0275d8"}, "value": "grey"}
        },
        "params": [{"name": "selection", "select": "interval"}],
        "config": {"axis": {"grid": false},"background": null, "style": {"cell": {"stroke": "transparent"}}, "tick": {"thickness": 0.5, "bandSize": 10}}
        };

    let brush_domains = {};
    let aux_domains = {"BO-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"CO-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"CO-agilent-75M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"DUE-varlociraptor":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"GHGA-sarek-bwa-deepvariant-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"GHGA-sarek-bwa-freebayes-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"GHGA-sarek-bwa-haplotypecaller-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"GHGA-sarek-bwa-strelka-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"GHGA-sarek-dragmap-deepvariant-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"GHGA-sarek-dragmap-freebayes-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"GHGA-sarek-dragmap-haplotypecaller-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"GHGA-sarek-dragmap-strelka-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"TB-sarek-freebayes-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"TB-sarek-freebayes-agilent-75M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"TB-sarek-haplotypecaller-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"TB-sarek-haplotypecaller-agilent-75M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"TB-sarek-strelka-agilent-200M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"TB-sarek-strelka-agilent-75M":["TB-sarek-freebayes-agilent-75M","GHGA-sarek-dragmap-freebayes-agilent-200M","CO-agilent-75M","BO-agilent-200M","DUE-varlociraptor","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-haplotypecaller-agilent-200M","TB-sarek-freebayes-agilent-200M","GHGA-sarek-bwa-deepvariant-agilent-200M","GHGA-sarek-bwa-freebayes-agilent-200M","GHGA-sarek-bwa-haplotypecaller-agilent-200M","GHGA-sarek-dragmap-deepvariant-agilent-200M","CO-agilent-200M","GHGA-sarek-dragmap-haplotypecaller-agilent-200M","TB-sarek-strelka-agilent-75M","TB-sarek-strelka-agilent-200M","GHGA-sarek-dragmap-strelka-agilent-200M","GHGA-sarek-bwa-strelka-agilent-200M"],"true_genotype":[]};

   function render_brush_plots(reset) {
   let tick_brush = 0;
       for (title of displayed_columns) {
           let index = tick_brush + 1;
           if (dp_num[tick_brush]) {
               let plot_data = [];
               let values = []
               for (row of table_rows) {
                   plot_data.push({"value": parseFloat(row[title])});
                   values.push(parseFloat(row[title]));
               }
               let min = Math.min(...values);
               let max = Math.max(...values);
               if (brush_domains[title] != undefined) {
                   min = brush_domains[title][0];
                   max = brush_domains[title][1];
               } else if (aux_domains[title] != undefined) {
                   aux_values = [min, max];
                   for (col of aux_domains[title]) {
                        for (row of table_rows) {
                            aux_values.push(parseFloat(row[col]));
                        }
                   }
                   min = Math.min(...aux_values);
                   max = Math.max(...aux_values);
               }
               if (Number.isInteger(min)) {
                   min = parseInt(min.toString());
               }
               if (Number.isInteger(max)) {
                   max = parseInt(max.toString());
               }
               let legend_tick_length = min.toString().length + max.toString().length;
               var s = tick_brush_specs;
               let has_labels = legend_tick_length < 8;
               s.encoding.x.axis.labels = has_labels;
               s.data.values = plot_data;
               s.name = title;
               s.encoding.x.axis.values = [min, max];
               s.encoding.x.scale.domain = [min, max];
               let brush_class = "";
               if (!has_labels) {
                   brush_class = "no-labels";
               }
               if(!reset) $(`table > thead > tr th:nth-child(${index})`).append(`<div class="filter-brush-container"><div class="filter-brush ${brush_class}" id="brush-${tick_brush}"></div></div>`);
               var opt = {"actions": false};
               vegaEmbed(`#brush-${tick_brush}`, JSON.parse(JSON.stringify(s)), opt).then(({spec, view}) => {
                   view.addSignalListener('selection', function(name, value) {
                       filter_boundaries[spec.name] = value;
                   });
                   view.addEventListener('mouseup', function(name, value) {
                       $('#table').bootstrapTable('filterBy', {"":""}, {
                           'filterAlgorithm': customFilter
                       })
                   });
               })
           } else {
           if(!reset){
               $(`table > thead > tr th:nth-child(${index})`).append(`<input class="form-control form-control-sm" id="filter-${index}" data-title="${title}" placeholder="Filter...">`);
                   $(`#filter-${index}`).on('input', function(event) {
                       filters[event.target.dataset.title] = $(`#filter-${index}`).val();
                       $('#table').bootstrapTable('filterBy', {"":""}, {
                           'filterAlgorithm': customFilter
                       })
                   });
               }
           }
           tick_brush++;
       }
   }

   render_brush_plots(false);


    function customFilter(row, filter) {
        for (title of displayed_columns) {
            if (filter_boundaries[title] !== undefined && !$.isEmptyObject(filter_boundaries[title])) {
                if (row[title] < filter_boundaries[title]['value'][0] || row[title] > filter_boundaries[title]['value'][1]) {
                    return false;
                }
            }
            if (filters[title] !== undefined && filters[title] !== "") {
                if (!row[title].includes(filters[title])) {
                    return false;
                }
            }
        }
        return true
    }
    

    $('#clear-filter').click(function clearFilter() {
        filter_boundaries = {};
        filters = {};
        $('#table').bootstrapTable('filterBy', {"":""}, {
            'filterAlgorithm': customFilter
        })
        $('.form-control').each( function() {
            $(this).val('');
        });
        render_brush_plots(true);
    });


    $('#table').on('page-change.bs.table', (number, size) => {
        setTimeout(function (){
        render(additional_headers, displayed_columns, table_rows, columns);
        }, 0);
    })

    let to_be_highlighted = parseInt(window.location.href.toString().split("highlight=").pop(), 10) + additional_headers.length;
    
    let page_size = $('#table').bootstrapTable('getOptions').pageSize;
    $('#table').bootstrapTable('selectPage', Math.floor(to_be_highlighted / page_size) + 1);
    
    let rows = $("table > tbody > tr");
    rows.each(function() {
        if (this.dataset.index == to_be_highlighted) {
            $(this).children().addClass('active-row');
            $('#table').bootstrapTable('scrollTo', {unit: 'rows', value: to_be_highlighted  % page_size})
        }
    });

    $( window ).resize(function() {
        var he = $( window ).height() - 150;
        // $('#table').bootstrapTable('resetView',{height: he});
    })
});

function renderMarkdownDescription() {
    var innerDescription = document.getElementById('innerDescription');
    var converter = new showdown.Converter();
    converter.setFlavor('github');
    innerDescription.innerHTML = converter.makeHtml(innerDescription.dataset.markdown);
}








function colorizeColumn0(ah, columns) {
    let detail_mode = columns.indexOf("BO-agilent-200M") == -1;
    let index = columns.indexOf("BO-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn1(ah, columns) {
    let detail_mode = columns.indexOf("CO-agilent-200M") == -1;
    let index = columns.indexOf("CO-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn2(ah, columns) {
    let detail_mode = columns.indexOf("CO-agilent-75M") == -1;
    let index = columns.indexOf("CO-agilent-75M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn3(ah, columns) {
    let detail_mode = columns.indexOf("DUE-varlociraptor") == -1;
    let index = columns.indexOf("DUE-varlociraptor") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn4(ah, columns) {
    let detail_mode = columns.indexOf("GHGA-sarek-bwa-deepvariant-agilent-200M") == -1;
    let index = columns.indexOf("GHGA-sarek-bwa-deepvariant-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn5(ah, columns) {
    let detail_mode = columns.indexOf("GHGA-sarek-bwa-freebayes-agilent-200M") == -1;
    let index = columns.indexOf("GHGA-sarek-bwa-freebayes-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn6(ah, columns) {
    let detail_mode = columns.indexOf("GHGA-sarek-bwa-haplotypecaller-agilent-200M") == -1;
    let index = columns.indexOf("GHGA-sarek-bwa-haplotypecaller-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn7(ah, columns) {
    let detail_mode = columns.indexOf("GHGA-sarek-bwa-strelka-agilent-200M") == -1;
    let index = columns.indexOf("GHGA-sarek-bwa-strelka-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn8(ah, columns) {
    let detail_mode = columns.indexOf("GHGA-sarek-dragmap-deepvariant-agilent-200M") == -1;
    let index = columns.indexOf("GHGA-sarek-dragmap-deepvariant-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn9(ah, columns) {
    let detail_mode = columns.indexOf("GHGA-sarek-dragmap-freebayes-agilent-200M") == -1;
    let index = columns.indexOf("GHGA-sarek-dragmap-freebayes-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn10(ah, columns) {
    let detail_mode = columns.indexOf("GHGA-sarek-dragmap-haplotypecaller-agilent-200M") == -1;
    let index = columns.indexOf("GHGA-sarek-dragmap-haplotypecaller-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn11(ah, columns) {
    let detail_mode = columns.indexOf("GHGA-sarek-dragmap-strelka-agilent-200M") == -1;
    let index = columns.indexOf("GHGA-sarek-dragmap-strelka-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn12(ah, columns) {
    let detail_mode = columns.indexOf("TB-sarek-freebayes-agilent-200M") == -1;
    let index = columns.indexOf("TB-sarek-freebayes-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn13(ah, columns) {
    let detail_mode = columns.indexOf("TB-sarek-freebayes-agilent-75M") == -1;
    let index = columns.indexOf("TB-sarek-freebayes-agilent-75M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn14(ah, columns) {
    let detail_mode = columns.indexOf("TB-sarek-haplotypecaller-agilent-200M") == -1;
    let index = columns.indexOf("TB-sarek-haplotypecaller-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn15(ah, columns) {
    let detail_mode = columns.indexOf("TB-sarek-haplotypecaller-agilent-75M") == -1;
    let index = columns.indexOf("TB-sarek-haplotypecaller-agilent-75M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn16(ah, columns) {
    let detail_mode = columns.indexOf("TB-sarek-strelka-agilent-200M") == -1;
    let index = columns.indexOf("TB-sarek-strelka-agilent-200M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn17(ah, columns) {
    let detail_mode = columns.indexOf("TB-sarek-strelka-agilent-75M") == -1;
    let index = columns.indexOf("TB-sarek-strelka-agilent-75M") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}

function colorizeColumn18(ah, columns) {
    let detail_mode = columns.indexOf("true_genotype") == -1;
    let index = columns.indexOf("true_genotype") + 1;
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["0/0"]).range(vega.scheme('category10'));
    let row = 0;
    $(`table > tbody > tr td:nth-child(${index})`).each(
        function() {
            if (row < ah) {
                row++;
                return;
            }
            value = this.innerHTML;
            if (value !== "" && !detail_mode) {
                this.style.backgroundColor = scale(value);
            }
            row++;
        }
    );
}



function colorizeDetailCard0(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard1(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard2(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard3(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard4(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard5(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard6(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard7(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard8(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard9(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard10(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard11(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard12(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard13(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard14(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard15(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard16(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard17(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["","0/1","1/1"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}

function colorizeDetailCard18(value, div) {
    var ordinal = vega.scale('ordinal');
    var scale = ordinal().domain(["0/0"]).range(vega.scheme('category10'));
    if (value !== "") {
        $(`${div}`).css( "background-color", scale(value) );
    }
}






function embedSearch(index) {
    var source = `search/column_${index}.html`;
    document.getElementById('search-iframe').setAttribute("src",source);
}





function addNumClass(dp_num, ah) {
    for (let i in dp_num) {
        if (dp_num[i]) {
            let row = 0;
            let n = parseInt(i) +  + 1;
            $(`table > tbody > tr td:nth-child(${n})`).each(
                function() {
                    if (row < ah) {
                        row++;
                        return;
                    }
                    this.classList.add("num-cell");
                    row++;
                }
            );
        }
    }
}

function render(additional_headers, displayed_columns, table_rows, columns) {







    colorizeColumn0(additional_headers.length, displayed_columns);

    colorizeColumn1(additional_headers.length, displayed_columns);

    colorizeColumn2(additional_headers.length, displayed_columns);

    colorizeColumn3(additional_headers.length, displayed_columns);

    colorizeColumn4(additional_headers.length, displayed_columns);

    colorizeColumn5(additional_headers.length, displayed_columns);

    colorizeColumn6(additional_headers.length, displayed_columns);

    colorizeColumn7(additional_headers.length, displayed_columns);

    colorizeColumn8(additional_headers.length, displayed_columns);

    colorizeColumn9(additional_headers.length, displayed_columns);

    colorizeColumn10(additional_headers.length, displayed_columns);

    colorizeColumn11(additional_headers.length, displayed_columns);

    colorizeColumn12(additional_headers.length, displayed_columns);

    colorizeColumn13(additional_headers.length, displayed_columns);

    colorizeColumn14(additional_headers.length, displayed_columns);

    colorizeColumn15(additional_headers.length, displayed_columns);

    colorizeColumn16(additional_headers.length, displayed_columns);

    colorizeColumn17(additional_headers.length, displayed_columns);

    colorizeColumn18(additional_headers.length, displayed_columns);



$('[data-toggle="popover"]').popover()
}
