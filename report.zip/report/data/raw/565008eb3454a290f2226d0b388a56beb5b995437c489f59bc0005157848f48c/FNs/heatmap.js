const heatmap_plot = {
    "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
    "data": {
        "values": []
    },
    "hconcat": [
        
        {
            "mark": {
                "type": "text",
                "align":"left"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'chromosome'",
                        "labelAngle": -45,
                        "labelOffset": 7,
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "text": {
                    "field": "chromosome",
                    "type": "quantitative",
                    "title": "chromosome",
                    
                }
            }
        },
        
        {
            "mark": {
                "type": "text",
                "align":"left"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'position'",
                        "labelAngle": -45,
                        "labelOffset": 7,
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "text": {
                    "field": "position",
                    "type": "quantitative",
                    "title": "position",
                    
                }
            }
        },
        
        {
            "mark": {
                "type": "text",
                "align":"left"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'ref_allele'",
                        "labelAngle": -45,
                        "labelOffset": 7,
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "text": {
                    "field": "ref_allele",
                    "type": "nominal",
                    "title": "ref_allele",
                    
                }
            }
        },
        
        {
            "mark": {
                "type": "text",
                "align":"left"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'alt_allele'",
                        "labelAngle": -45,
                        "labelOffset": 7,
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "text": {
                    "field": "alt_allele",
                    "type": "nominal",
                    "title": "alt_allele",
                    
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'true_genotype'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "true_genotype",
                    "type": "nominal",
                    "title": "true_genotype",
                    "scale": {
                        "domain": ["0/0","0/1","1/1"],
                        "type": "ordinal",
                        
                        "range": ["#fdae6b","#c6dbef","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'DUE-varlociraptor'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "DUE-varlociraptor",
                    "type": "nominal",
                    "title": "DUE-varlociraptor",
                    "scale": {
                        "domain": ["0/0","0/1","1/1"],
                        "type": "ordinal",
                        
                        "range": ["#fdae6b","#c6dbef","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'TB-sarek-freebayes-agilent-200M'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "TB-sarek-freebayes-agilent-200M",
                    "type": "nominal",
                    "title": "TB-sarek-freebayes-agilent-200M",
                    "scale": {
                        "domain": ["0/0","0/1","1/1"],
                        "type": "ordinal",
                        
                        "range": ["#fdae6b","#c6dbef","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'TB-sarek-freebayes-agilent-75M'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "TB-sarek-freebayes-agilent-75M",
                    "type": "nominal",
                    "title": "TB-sarek-freebayes-agilent-75M",
                    "scale": {
                        "domain": ["0/0","0/1","1/1"],
                        "type": "ordinal",
                        
                        "range": ["#fdae6b","#c6dbef","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'TB-sarek-haplotypecaller-agilent-200M'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "TB-sarek-haplotypecaller-agilent-200M",
                    "type": "nominal",
                    "title": "TB-sarek-haplotypecaller-agilent-200M",
                    "scale": {
                        "domain": ["0/0","0/1","1/1"],
                        "type": "ordinal",
                        
                        "range": ["#fdae6b","#c6dbef","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'TB-sarek-haplotypecaller-agilent-75M'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "TB-sarek-haplotypecaller-agilent-75M",
                    "type": "nominal",
                    "title": "TB-sarek-haplotypecaller-agilent-75M",
                    "scale": {
                        "domain": ["0/0","0/1","1/1"],
                        "type": "ordinal",
                        
                        "range": ["#fdae6b","#c6dbef","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'TB-sarek-strelka-agilent-200M'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "TB-sarek-strelka-agilent-200M",
                    "type": "nominal",
                    "title": "TB-sarek-strelka-agilent-200M",
                    "scale": {
                        "domain": ["0/0","0/1","1/1"],
                        "type": "ordinal",
                        
                        "range": ["#fdae6b","#c6dbef","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'TB-sarek-strelka-agilent-75M'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "TB-sarek-strelka-agilent-75M",
                    "type": "nominal",
                    "title": "TB-sarek-strelka-agilent-75M",
                    "scale": {
                        "domain": ["0/0","0/1","1/1"],
                        "type": "ordinal",
                        
                        "range": ["#fdae6b","#c6dbef","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'BO-agilent-200M'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "BO-agilent-200M",
                    "type": "nominal",
                    "title": "BO-agilent-200M",
                    "scale": {
                        "domain": ["0/0","0/1","1/1"],
                        "type": "ordinal",
                        
                        "range": ["#fdae6b","#c6dbef","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'CO-agilent-200M'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "CO-agilent-200M",
                    "type": "nominal",
                    "title": "CO-agilent-200M",
                    "scale": {
                        "domain": ["0/0","0/1","1/1"],
                        "type": "ordinal",
                        
                        "range": ["#fdae6b","#c6dbef","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'CO-agilent-75M'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "CO-agilent-75M",
                    "type": "nominal",
                    "title": "CO-agilent-75M",
                    "scale": {
                        "domain": ["0/0","0/1","1/1"],
                        "type": "ordinal",
                        
                        "range": ["#fdae6b","#c6dbef","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        }
        
    ],
    "config": {
        "style": {"cell": {"stroke": "transparent"}, "guide-label": {"fontWeight": "bold"}},
        "concat": {"spacing": 4},
        "text": {"limit": 135}
    }
}