const heatmap_plot = {
    "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
    "data": {
        "values": []
    },
    "hconcat": [
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'callset'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "callset",
                    "type": "nominal",
                    "title": "callset",
                    "scale": {
                        "domain": ["CO-agilent-75M","TB-sarek-freebayes-agilent-75M","TB-sarek-haplotypecaller-agilent-75M","TB-sarek-strelka-agilent-75M"],
                        "type": "ordinal",
                        "scheme": "category20",
                        
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'coverage'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "coverage",
                    "type": "nominal",
                    "title": "coverage",
                    "scale": {
                        "domain": ["low","medium","high"],
                        "type": "ordinal",
                        
                        "range": ["#c6dbef","#9ecae1","#6baed6"],
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'precision'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "precision",
                    "type": "quantitative",
                    "title": "precision",
                    "scale": {
                        "domain": [0.7354085445404053,0.9174800515174866],
                        "type": "linear",
                        "scheme": "blues",
                        
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "text",
                "align":"left"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'tp_query'",
                        "labelAngle": -45,
                        "labelOffset": 7,
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "text": {
                    "field": "tp_query",
                    "type": "quantitative",
                    "title": "tp_query",
                    
                }
            }
        },
        
        {
            "mark": {
                "type": "text",
                "align":"left"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'fp'",
                        "labelAngle": -45,
                        "labelOffset": 7,
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "text": {
                    "field": "fp",
                    "type": "quantitative",
                    "title": "fp",
                    
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'recall'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "recall",
                    "type": "quantitative",
                    "title": "recall",
                    "scale": {
                        "domain": [0.4797297418117523,0.9850606918334961],
                        "type": "linear",
                        "scheme": "blues",
                        
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        },
        
        {
            "mark": {
                "type": "text",
                "align":"left"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'tp_truth'",
                        "labelAngle": -45,
                        "labelOffset": 7,
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "text": {
                    "field": "tp_truth",
                    "type": "quantitative",
                    "title": "tp_truth",
                    
                }
            }
        },
        
        {
            "mark": {
                "type": "text",
                "align":"left"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'fn'",
                        "labelAngle": -45,
                        "labelOffset": 7,
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "text": {
                    "field": "fn",
                    "type": "quantitative",
                    "title": "fn",
                    
                }
            }
        },
        
        {
            "mark": {
                "type": "rect"
            },
            "encoding": {
                "x": {
                "field": "dummy",
                    "axis": {
                        "labelExpr": "'genotype_mismatch_rate'",
                        "labelAngle": -45,
                        
                        "title": null,
                        "ticks": false,
                        "orient": "top",
                        "domain": false
                    }
                },
                "y": {
                    "field": "index",
                    "type": "ordinal",
                    "axis": null,
                },
                "color": {
                    "field": "genotype_mismatch_rate",
                    "type": "quantitative",
                    "title": "genotype_mismatch_rate",
                    "scale": {
                        "domain": [0.01837524212896824,0.17582418024539948],
                        "type": "linear",
                        "scheme": "blues",
                        
                    },
                    "legend": {
                        "orient": "bottom",
                        "direction": "vertical",
                        "gradientLength": 50
                    }
                }
            }
        }
        
    ],
    "config": {
        "style": {"cell": {"stroke": "transparent"}, "guide-label": {"fontWeight": "bold"}},
        "concat": {"spacing": 4},
        "text": {"limit": 135}
    }
}