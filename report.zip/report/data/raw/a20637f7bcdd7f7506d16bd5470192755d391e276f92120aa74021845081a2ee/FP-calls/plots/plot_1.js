let show_plot_1 = true;
let plot_1 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"bin_end":6318688.0,"bin_start":null,"value":0},{"bin_end":17830304.0,"bin_start":6318688.0,"value":5},{"bin_end":29341918.0,"bin_start":17830304.0,"value":2},{"bin_end":40853532.0,"bin_start":29341918.0,"value":2},{"bin_end":52365148.0,"bin_start":40853532.0,"value":5},{"bin_end":63876760.0,"bin_start":52365148.0,"value":0},{"bin_end":75388376.0,"bin_start":63876760.0,"value":0},{"bin_end":86899992.0,"bin_start":75388376.0,"value":0},{"bin_end":98411608.0,"bin_start":86899992.0,"value":3},{"bin_end":109923224.0,"bin_start":98411608.0,"value":0},{"bin_end":121434832.0,"bin_start":109923224.0,"value":0},{"bin_end":132946448.0,"bin_start":121434832.0,"value":0},{"bin_end":144458064.0,"bin_start":132946448.0,"value":2},{"bin_end":155969680.0,"bin_start":144458064.0,"value":0},{"bin_end":167481296.0,"bin_start":155969680.0,"value":0},{"bin_end":178992912.0,"bin_start":167481296.0,"value":0},{"bin_end":190504528.0,"bin_start":178992912.0,"value":1},{"bin_end":202016144.0,"bin_start":190504528.0,"value":0},{"bin_end":213527760.0,"bin_start":202016144.0,"value":1},{"bin_end":225039376.0,"bin_start":213527760.0,"value":0},{"bin_end":236550976.0,"bin_start":225039376.0,"value":0},{"bin_end":null,"bin_start":236550992.0,"value":1}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "bin_start",
                    "bin": "binned",
                    "title": "position"
                },
                "x2": {"field": "bin_end"},
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        },
        {
            "data": {
                "values":[]
            },
            "mark": "rule",
            "encoding": {
                "x": {"field": "bin_start", "bin": "binned"},
                "color": {"value": "red"}
            }
        }
    ]
};
