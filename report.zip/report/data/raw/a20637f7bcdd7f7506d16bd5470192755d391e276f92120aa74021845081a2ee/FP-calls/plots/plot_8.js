let show_plot_8 = true;
let plot_8 = {
    "$schema": "https://vega.github.io/schema/vega-lite/v4.json",
    "width": "container",
    "layer": [
        {
            "data": {"values": [{"key":"1/1","value":1},{"key":"0/1","value":3}]},
            "mark": "bar",
            "encoding": {
                "x": {
                    "field": "key",
                    "sort": {"field": "value", "order": "descending"},
                    "title": "BO-agilent-200M"
                },
                "y": {"field": "value", "type": "quantitative", "title": null}
            }
        }
    ]
};
